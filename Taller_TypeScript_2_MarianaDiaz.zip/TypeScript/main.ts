import {Serie} from './serie.js';
import {series} from "./data.js";

let serieTable: HTMLElement = document.getElementById("serie")!;
let promedios: HTMLElement = document.getElementById("promedios")!;
let detalle: HTMLElement = document.getElementById('infoSerie')!;



function mostrarInfoSerie(series: Serie[]): void
{
    let tbodySerie:HTMLElement = document.createElement("tbody");

    for (let serie of series)
    {
        let trElement: HTMLElement = document.createElement("tr");
        trElement.setAttribute("class","clickable");
        trElement.onclick = function(){mostrarDetalle(serie)};
        trElement.innerHTML = `<th scope ="row">${serie.idSerie}</th>
        <td>${serie.nombre}</td>
        <td>${serie.canal}</td>
        <td>${serie.temporadas}</td>`;
        tbodySerie.appendChild(trElement)
    }
    serieTable.appendChild(tbodySerie);
}

function calcularPromedios(series: Serie[]): void{

    let suma: number = 0;
    let cantidad: number = 0;

    for (let serie of series)
    {
        suma += serie.temporadas;
        cantidad ++;
    }

    let promedio: number = suma/cantidad;

    let tPromedio = document.createElement("tr");

    tPromedio.innerHTML = `<tc><td>Seasons Average:  </td><td>${promedio}</td></tc>`
    promedios.appendChild(tPromedio);
}

function mostrarDetalle (serie:Serie) : void
{
    detalle.innerHTML = "";
    let serieDetalle = document.createElement("div");   
    serieDetalle.innerHTML = `<div class="card_serie">
                        <img class="card-img-top" src= ${serie.imagen} />
                        <div class="card-body">
                        <h4 class="card-title">${serie.nombre}</h4>
                        <p1 class="card-text">${serie.sinopsis}</p1>
                        <br>
                        <br>
                        <a id= "idLink"
                        href=${serie.url}
                        target="_blank"
                        >Veala por si mismo!</a>
                        </div>
                        </div>`;
    detalle.appendChild(serieDetalle);
}


mostrarInfoSerie(series);
calcularPromedios(series);
