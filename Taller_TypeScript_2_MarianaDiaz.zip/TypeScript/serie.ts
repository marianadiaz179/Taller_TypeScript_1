export class Serie{

    constructor(public idSerie: number, public nombre: string, public canal: string, public temporadas: number,
        public sinopsis: string, public url: string, public imagen: string)
    {

    }

}
