import { series } from "./data.js";
var serieTable = document.getElementById("serie");
var promedios = document.getElementById("promedios");
var detalle = document.getElementById('infoSerie');
function mostrarInfoSerie(series) {
    var tbodySerie = document.createElement("tbody");
    var _loop_1 = function (serie) {
        var trElement = document.createElement("tr");
        trElement.setAttribute("class", "clickable");
        trElement.onclick = function () { mostrarDetalle(serie); };
        trElement.innerHTML = "<th scope =\"row\">".concat(serie.idSerie, "</th>\n        <td>").concat(serie.nombre, "</td>\n        <td>").concat(serie.canal, "</td>\n        <td>").concat(serie.temporadas, "</td>");
        tbodySerie.appendChild(trElement);
    };
    for (var _i = 0, series_1 = series; _i < series_1.length; _i++) {
        var serie = series_1[_i];
        _loop_1(serie);
    }
    serieTable.appendChild(tbodySerie);
}
function calcularPromedios(series) {
    var suma = 0;
    var cantidad = 0;
    for (var _i = 0, series_2 = series; _i < series_2.length; _i++) {
        var serie = series_2[_i];
        suma += serie.temporadas;
        cantidad++;
    }
    var promedio = suma / cantidad;
    var tPromedio = document.createElement("tr");
    tPromedio.innerHTML = "<tc><td>Seasons Average:  </td><td>".concat(promedio, "</td></tc>");
    promedios.appendChild(tPromedio);
}
function mostrarDetalle(serie) {
    detalle.innerHTML = "";
    var serieDetalle = document.createElement("div");
    serieDetalle.innerHTML = "<div class=\"card_serie\">\n                        <img class=\"card-img-top\" src= ".concat(serie.imagen, " />\n                        <div class=\"card-body\">\n                        <h4 class=\"card-title\">").concat(serie.nombre, "</h4>\n                        <p1 class=\"card-text\">").concat(serie.sinopsis, "</p1>\n                        <br>\n                        <br>\n                        <a id= \"idLink\"\n                        href=").concat(serie.url, "\n                        target=\"_blank\"\n                        >Veala por si mismo!</a>\n                        </div>\n                        </div>");
    detalle.appendChild(serieDetalle);
}
mostrarInfoSerie(series);
calcularPromedios(series);
