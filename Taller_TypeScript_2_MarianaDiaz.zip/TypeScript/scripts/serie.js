var Serie = /** @class */ (function () {
    function Serie(idSerie, nombre, canal, temporadas, sinopsis, url, imagen) {
        this.idSerie = idSerie;
        this.nombre = nombre;
        this.canal = canal;
        this.temporadas = temporadas;
        this.sinopsis = sinopsis;
        this.url = url;
        this.imagen = imagen;
    }
    return Serie;
}());
export { Serie };
